document.addEventListener('DOMContentLoaded', function() {
    // Attach an event listener to the 'Save' button
   


    document.getElementById('bbb').addEventListener('click', function() {
        // Get the value from the input field
        var inputValue = document.getElementById('somebs').value;
        // Use the input value in your JavaScript
        console.log("Saved input: " + inputValue);
    });
const form = document.getElementById('quiz-form');
        const resultDiv = document.getElementById('result');
        var inputVal  = document.getElementById('somebs').value;

        form.addEventListener('submit', function(event) {
            event.preventDefault();
            const formData = new FormData(this); 
            let score = 0;
            let answersQ6 = [];
            
            formData.forEach((value, key) => {
                if (key === 'q1' && value == 'answer1') {
                    score += 10;
                   
                }
                if (key === 'q2' && value == 'answer2') {
                    score += 10;
                   
                }
                if (key === 'q3' && value == 'cooking') {
                    
                    score += 10;
                   
                }
                
                if (key === 'q4' && value =='answer3') {
                    score += 10;
                    
                }
                if (key === 'q5' && value =='answer4') {
                    score += 10;
                    
                }
                if (key === 'q6') {
                    answersQ6.push(value);
                     
                }
            });
            
            
            for (var pair of formData.entries()) {
                console.log(pair[0]+ ': ' + pair[1]);
            }

            if (answersQ6.includes('answer1') && answersQ6.includes('answer2')) {
                score += 10;
            }

            displayResult(score); 
        });

        function displayResult(score) {
            resultDiv.innerHTML = `Your score: ${score}`;
            resultDiv.style.display = 'block'; 
        }
       
});